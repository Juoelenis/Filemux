use std::fs;
use std::path::Path;
use std::sync::mpsc;
use std::thread;
use std::time::Duration;
use walkdir::WalkDir;
use eframe::egui;

fn clean_directory(directory: &str, extension: &str) -> Result<(), String> {
    for entry in WalkDir::new(directory) {
        let entry = entry.map_err(|e| e.to_string())?;
        let path = entry.path();

        // Check if it's a file and if it matches the extension
        if path.is_file() {
            if let Some(ext) = path.extension() {
                if ext == extension {
                    println!("Deleting file: {:?}", path);
                    fs::remove_file(path).map_err(|e| e.to_string())?;
                }
            }
        }
    }
    Ok(())
}

struct FileCleanerApp {
    directory: String,
    extension: String,
    status: String,
}

impl Default for FileCleanerApp {
    fn default() -> Self {
        Self {
            directory: String::from(""),
            extension: String::from("txt"),
            status: String::from(""),
        }
    }
}

impl eframe::App for FileCleanerApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        egui::CentralPanel::default().show(ctx, |ui| {
            ui.heading("File Cleaner");

            ui.horizontal(|ui| {
                ui.label("Directory: ");
                ui.text_edit_singleline(&mut self.directory);
            });

            ui.horizontal(|ui| {
                ui.label("File Extension: ");
                ui.text_edit_singleline(&mut self.extension);
            });

            if ui.button("Clean Directory").clicked() {
                let directory = self.directory.clone();
                let extension = self.extension.clone();
                let (tx, rx) = mpsc::channel();
                self.status = "Cleaning...".into();

                thread::spawn(move || {
                    match clean_directory(&directory, &extension) {
                        Ok(_) => tx.send("Cleaning completed!").unwrap(),
                        Err(e) => tx.send(format!("Error: {}", e)).unwrap(),
                    }
                });

                let ctx = ctx.clone();
                thread::spawn(move || {
                    // Poll for results in a separate thread
                    loop {
                        if let Ok(result) = rx.try_recv() {
                            ctx.request_repaint(); // Request GUI repaint
                            println!("{}", result); // Print result to console
                            break;
                        }
                        thread::sleep(Duration::from_millis(100));
                    }
                });
            }

            ui.label(&self.status);
        });
    }
}

fn main() -> Result<(), eframe::Error> {
    let native_options = eframe::NativeOptions::default();
    eframe::run_native(
        "File Cleaner",
        native_options,
        Box::new(|_cc| Box::<FileCleanerApp>::default()),
    )
}
